#%%
import numpy as np
import matplotlib.pyplot as plt
t = 20*np.arange(18)
v=np.array([0,14,23,29,34,37,39,40,41,42,43,43,43,43,43,43,43,43])
#%%

# courbe
plt.figure()
plt.plot(t,v,'bo', label='vitesse')
plt.legend()
plt.grid()
plt.xlabel("temps")
plt.ylabel("vitesse")
plt.title("Vitesse de la bille en fonction du temps")
plt.show()
#%%
al=[]
m=np.arange(len(t)-2)
for i in m :
    a=(v[i+2]-v[i])/(t[i+2]-t[i])
    al.append(a)
v0=v[1:-1]
# regression lineaire
mod=np.polyfit(v0,al,1)
model=mod[0]*v0+mod[1]

print(mod)
#%%
# Courbe
plt.figure()
plt.plot(v0,al,'ro',label='points expérimentaux')
plt.plot(v0,model,'b-',label='modèle affine')
plt.legend()
plt.grid()
plt.xlabel("vitesse")
plt.ylabel("accélération")
plt.title("Modèle de la force subie par la bille")
plt.show()
